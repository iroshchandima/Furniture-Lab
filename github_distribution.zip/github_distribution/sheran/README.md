# Sheran - Admin & Analytics

## Responsibilities

- Admin dashboard implementation
- Inventory management
- Order tracking system
- Analytics and reporting
- Admin user management
- System monitoring

## Files

- src/components/AdminDashboard.jsx
- Admin panel components
- Inventory management components
- Analytics components
- Reporting utilities
- Admin authentication
