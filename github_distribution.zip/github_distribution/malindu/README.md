# Malindu - Product Catalog & UI

## Responsibilities

- Product catalog implementation
- Product card components
- Product filtering and search
- Product details pages
- Product categorization
- Product image handling

## Files

- src/components/ProductCard.jsx
- Product listing components
- Product detail components
- Product filtering components
- Product search functionality
- Product data management
